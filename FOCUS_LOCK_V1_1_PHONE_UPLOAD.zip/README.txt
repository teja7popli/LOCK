FOCUS LOCK v1.0
Personal offline focus blocker.

FEATURES
- Select only the apps you want blocked.
- Block website domains such as youtube.com.
- Different schedules for MON-SUN.
- Exact-date overrides replace the weekly schedule.
- Settings freeze 1 hour before the first block.
- Offline, no account, no server.

ANDROID LIMITATION
A normal Android APK cannot guarantee absolute immunity from Force Stop or uninstall.
Device-owner/device-policy modes are a separate Android administration model.
Website blocking is best-effort because browser accessibility data varies.

BUILD
Use the GitHub Actions workflow supplied with this project:
- checkout
- set up Java 17
- set up Android SDK
- install platform 35/build-tools 35.0.0
- install Gradle 8.10.2
- run: gradle assembleDebug --no-daemon
- upload: app/build/outputs/apk/debug/app-debug.apk
