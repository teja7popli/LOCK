package com.tejas.focuslock;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.*;

public class BlockAccessibilityService extends AccessibilityService {
    long last=0;
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(!LockState.isBlockedNow(this)) return;
        String pkg=e.getPackageName()==null?"":e.getPackageName().toString();
        if(LockState.appSelected(this,pkg) || siteHit(e.getSource())){
            if(System.currentTimeMillis()-last<700)return;
            last=System.currentTimeMillis();
            Intent i=new Intent(this,BlockActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(i);
        }
    }
    boolean siteHit(AccessibilityNodeInfo n){
        if(n==null)return false;
        if(n.getText()!=null && LockState.siteSelected(this,n.getText().toString()))return true;
        if(n.getContentDescription()!=null && LockState.siteSelected(this,n.getContentDescription().toString()))return true;
        for(int i=0;i<n.getChildCount();i++){
            AccessibilityNodeInfo c=n.getChild(i);
            if(c!=null){boolean h=siteHit(c);c.recycle();if(h)return true;}
        }
        return false;
    }
    @Override public void onInterrupt(){}
}
