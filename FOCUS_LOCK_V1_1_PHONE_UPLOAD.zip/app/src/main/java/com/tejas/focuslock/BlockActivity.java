package com.tejas.focuslock;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class BlockActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER); l.setPadding(40,40,40,40);
        l.setBackgroundColor(Color.rgb(10,10,15));
        TextView t=new TextView(this);
        t.setText("FOCUS LOCK\n\nSTUDY BLOCK ACTIVE\n\nThis app is blocked by your timetable.");
        t.setTextColor(Color.WHITE); t.setTextSize(22); t.setGravity(Gravity.CENTER);
        l.addView(t);
        Button back=new Button(this); back.setText("BACK TO STUDY");
        back.setOnClickListener(v->finishAndRemoveTask()); l.addView(back);
        setContentView(l);
    }
    @Override public void onBackPressed(){finishAndRemoveTask();}
}
