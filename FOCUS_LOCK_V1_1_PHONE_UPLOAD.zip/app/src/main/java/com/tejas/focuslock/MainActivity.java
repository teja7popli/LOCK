package com.tejas.focuslock;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    final String[] days={"MON","TUE","WED","THU","FRI","SAT","SUN"};

    @Override public void onCreate(Bundle b){super.onCreate(b);build();}
    TextView tx(String s,int z){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);t.setPadding(0,12,0,12);return t;
    }
    void build(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,24,28,40);root.setBackgroundColor(Color.rgb(10,10,15));sv.addView(root);setContentView(sv);
        root.addView(tx("FOCUS LOCK",30));root.addView(tx("Automatic app + website blocker",16));
        Button a=btn("1. ENABLE BLOCKING ACCESS");a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(a);
        Button ap=btn("2. SELECT APPS TO BLOCK");ap.setOnClickListener(v->chooseApps());root.addView(ap);
        Button si=btn("3. SELECT WEBSITES TO BLOCK");si.setOnClickListener(v->editSites());root.addView(si);
        root.addView(tx("WEEKLY TIMETABLE",20));
        for(String d:days){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.addView(tx(d,16),new LinearLayout.LayoutParams(0,-2,1));Button e=btn("EDIT");e.setOnClickListener(v->editDay(d));r.addView(e);root.addView(r);}
        root.addView(tx("DATE OVERRIDES",20));
        root.addView(tx("A date override replaces that date's weekly timetable. Settings freeze 1 hour before the first block.",14));
        Button o=btn("ADD / EDIT DATE OVERRIDE");o.setOnClickListener(v->editOverride());root.addView(o);
        Button st=btn("CHECK CURRENT STATUS");st.setOnClickListener(v->Toast.makeText(this,LockState.isBlockedNow(this)?"BLOCKING ACTIVE":"NOT BLOCKED",Toast.LENGTH_SHORT).show());root.addView(st);
        root.addView(tx("Android does not allow an ordinary APK to guarantee immunity from Force Stop or uninstall. This build uses OS-controlled AccessibilityService enforcement.",12));
    }
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    void editDay(String d){
        if(!LockState.editableNow(this)){Toast.makeText(this,"Settings locked.",Toast.LENGTH_LONG).show();return;}
        EditText in=new EditText(this);in.setHint("16:00-18:00,18:30-20:30,22:00-02:00");in.setText(LockState.p(this).getString("day_"+d,""));
        new AlertDialog.Builder(this).setTitle(d+" schedule").setMessage("24-hour time; separate blocks with commas.").setView(in)
        .setPositiveButton("SAVE",(x,w)->LockState.p(this).edit().putString("day_"+d,in.getText().toString().trim()).apply()).setNegativeButton("CANCEL",null).show();
    }
    void chooseApps(){
        if(!LockState.editableNow(this)){Toast.makeText(this,"Settings locked.",Toast.LENGTH_LONG).show();return;}
        android.content.pm.PackageManager pm=getPackageManager();
        ArrayList<android.content.pm.ApplicationInfo> list=new ArrayList<>(pm.getInstalledApplications(0));
        list.removeIf(a->a.packageName.equals(getPackageName())||pm.getLaunchIntentForPackage(a.packageName)==null);
        list.sort((x,y)->pm.getApplicationLabel(x).toString().compareToIgnoreCase(pm.getApplicationLabel(y).toString()));
        String[] names=new String[list.size()];boolean[] ch=new boolean[list.size()];Set<String> sel=LockState.set(this,LockState.APPS);
        for(int i=0;i<list.size();i++){names[i]=pm.getApplicationLabel(list.get(i)).toString();ch[i]=sel.contains(list.get(i).packageName);}
        new AlertDialog.Builder(this).setTitle("Apps to block").setMultiChoiceItems(names,ch,(d,w,c)->{})
        .setPositiveButton("SAVE",(d,w)->{ListView lv=((AlertDialog)d).getListView();HashSet<String> out=new HashSet<>();for(int i=0;i<lv.getCount();i++)if(lv.isItemChecked(i))out.add(list.get(i).packageName);LockState.p(this).edit().putStringSet(LockState.APPS,out).apply();})
        .setNegativeButton("CANCEL",null).show();
    }
    void editSites(){
        if(!LockState.editableNow(this)){Toast.makeText(this,"Settings locked.",Toast.LENGTH_LONG).show();return;}
        EditText in=new EditText(this);in.setHint("youtube.com, instagram.com");in.setText(String.join(", ",LockState.set(this,LockState.SITES)));
        new AlertDialog.Builder(this).setTitle("Blocked website domains").setMessage("Domains separated by commas. Website blocking is best-effort and depends on browser accessibility data.")
        .setView(in).setPositiveButton("SAVE",(d,w)->{HashSet<String>s=new HashSet<>();for(String x:in.getText().toString().split(","))if(!x.trim().isEmpty())s.add(x.trim().toLowerCase(Locale.US));LockState.p(this).edit().putStringSet(LockState.SITES,s).apply();})
        .setNegativeButton("CANCEL",null).show();
    }
    void editOverride(){
        if(!LockState.editableNow(this)){Toast.makeText(this,"Settings locked.",Toast.LENGTH_LONG).show();return;}
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText date=new EditText(this);date.setHint("YYYY-MM-DD");EditText sch=new EditText(this);sch.setHint("16:00-18:00,18:30-20:30");l.addView(date);l.addView(sch);
        new AlertDialog.Builder(this).setTitle("Date override").setMessage("Exact date; it replaces the weekly timetable for that date.").setView(l)
        .setPositiveButton("SAVE",(d,w)->{String k=date.getText().toString().trim();if(k.matches("\\d{4}-\\d{2}-\\d{2}"))LockState.p(this).edit().putString("override_"+k,sch.getText().toString().trim()).apply();})
        .setNegativeButton("CANCEL",null).show();
    }
}
