package com.tejas.focuslock;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.*;

public final class LockState {
    static final String PREF="focus_lock", APPS="apps", SITES="sites";
    static SharedPreferences p(Context c){ return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    static String todayKey(){
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }
    static String dowKey(Calendar c){
        return new SimpleDateFormat("EEE", Locale.US).format(c.getTime()).toUpperCase(Locale.US);
    }
    static boolean within(String start,String end,Calendar now){
        try{
            String[] a=start.split(":"), b=end.split(":");
            Calendar s=(Calendar)now.clone(), e=(Calendar)now.clone();
            s.set(Calendar.HOUR_OF_DAY,Integer.parseInt(a[0])); s.set(Calendar.MINUTE,Integer.parseInt(a[1])); s.set(Calendar.SECOND,0);
            e.set(Calendar.HOUR_OF_DAY,Integer.parseInt(b[0])); e.set(Calendar.MINUTE,Integer.parseInt(b[1])); e.set(Calendar.SECOND,59);
            if(!e.after(s)) e.add(Calendar.DAY_OF_MONTH,1);
            return !now.before(s)&&!now.after(e);
        }catch(Exception x){return false;}
    }
    static String schedule(Context c){
        String o=p(c).getString("override_"+todayKey(),"");
        if(!o.isEmpty()) return o;
        return p(c).getString("day_"+dowKey(Calendar.getInstance()),"");
    }
    static boolean isBlockedNow(Context c){
        String s=schedule(c); if(s.isEmpty()) return false;
        Calendar n=Calendar.getInstance();
        for(String b:s.split(",")){
            String[] z=b.trim().split("-");
            if(z.length==2 && within(z[0],z[1],n)) return true;
        }
        return false;
    }
    static Set<String> set(Context c,String k){ return new HashSet<>(p(c).getStringSet(k,new HashSet<String>())); }
    static boolean appSelected(Context c,String pkg){ return set(c,APPS).contains(pkg); }
    static boolean siteSelected(Context c,String text){
        String x=text.toLowerCase(Locale.US);
        for(String s:set(c,SITES)) if(!s.isEmpty() && x.contains(s.toLowerCase(Locale.US))) return true;
        return false;
    }
    static boolean editableNow(Context c){
        String s=schedule(c); if(s.isEmpty()) return true;
        String first=null;
        for(String b:s.split(",")){
            String[] z=b.trim().split("-");
            if(z.length==2 && (first==null || z[0].compareTo(first)<0)) first=z[0];
        }
        if(first==null) return true;
        try{
            String[] a=first.split(":"); Calendar lock=Calendar.getInstance();
            lock.set(Calendar.HOUR_OF_DAY,Integer.parseInt(a[0])); lock.set(Calendar.MINUTE,Integer.parseInt(a[1])); lock.set(Calendar.SECOND,0);
            lock.add(Calendar.HOUR_OF_DAY,-1);
            return Calendar.getInstance().before(lock);
        }catch(Exception e){return true;}
    }
}
